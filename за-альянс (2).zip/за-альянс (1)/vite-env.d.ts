// This file is misplaced. Its content has been moved to src/vite-env.d.ts
// to conform to standard Vite project structure and resolve type errors.
